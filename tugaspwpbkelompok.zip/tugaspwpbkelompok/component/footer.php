<div class="top-footer">
	<h2><i class='bx bx-envelope'></i>Sign up for Newslatter</h2>
	<div class="input-field">
		<input type="text" name="" placeholder="email addres"><button type="submit" class="btn">Subscribe</button>
	</div>
<footer class="footer">
	<div class="overlay">
	<div class="footer-content">
		<div class="img-box">
			<img src="image/download.png">
		</div>
		<div class="inner-footer">
			<div class="card">
				<h3>about Us</h3>
				<ul>
					<li>about us</li>
					<li>our difference</li>
					<li>comunity matters</li>
					<li>press</li>
					<li>blog</li>
					<li>bouqs video</li>
				</ul>
			</div>
			<div class="card">
				<h3>services</h3>
				<ul>
					<li>order</li>
					<li>help center</li>
					<li>shipping</li>
					<li>term of use</li>
					<li>acount detail</li>
					<li>my acount</li>
				</ul>
			</div>
			<div class="card">
				<h3>Team</h3>
				<ul>
					<li>Riski aditia</li>
					<li>Adrian maulana</li>
					<li>Raihan kusdinar</li>
					<li>Rifa mustofa</li>
					<li>Muhammad Miftah </li>
				</ul>
			</div>
			<div class="card">
				<h3>newsletter</h3>
				<p>sign up for Newslatter</p>
				<div class="social-links">
					<i class='bx bxl-instagram' ></i>
					<i class='bx bxl-facebook' ></i>
					<i class='bx bxl-twitter' ></i>
					<i class='bx bxl-tiktok' ></i>
					<i class='bx bxl-youtube' ></i>
				</div>
			</div>
			<div class="bottom-footer">
			<p>all right reserved - code with riski,miftah,raihan,ripa,adrian </p>
			</div>
</div>

			
		</div>
</footer>
</div>